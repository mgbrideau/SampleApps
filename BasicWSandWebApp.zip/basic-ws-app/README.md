# Udemy:
https://www.udemy.com/course/restful-web-service-with-spring-boot-jpa-and-mysql/learn/lecture/9798084#overview


# Quick App Start
### Start MySQL
* Open CMD window: mysqld
* Open MySQL Workbench
* Query basic_webapp.Users

### Start basic_ws_app
* com.basic.ws.app.MobileAppWsApplicaiton -> Run As Java Application
* Wait for: Started MobileAppWsApplication in 10.248 seconds (JVM running for 11.599)

### Run Postman
* Run Post NLAC user - Create 
* Run Post NLAC user - Login 
- Capture Bearer
* Run Get NLAC users

### Run Web Application:
* basic-spring-mvc-webapp -> Maven Clean/Install -> Run As: On Server

# This will generate a full up WS MavenProject:

## https://start.spring.io
* Project: MavenProject
* Language: Java
* Spring Boot: 2.2.5
* Project Metadata
* Group: com.brideau.app.ws
* Artifact: basic_ws_app
* Dependencies: Spring Web Security

# Start MySQL
* Open CMD window
* cd %HOMEPATH%
* mysqld
* Leave this cmd window open

### Open new cmd window
* mysql -u mbrideau -p


# Oracle will not allow POM's to download drivers
* see https://mkyong.com/maven/how-to-add-oracle-jdbc-driver-in-your-maven-local-repository/
* Download drivers from: 
    https://www.oracle.com/database/technologies/appdev/jdbc-ucp-19c-downloads.html
	mvn install:install-file -Dfile=ojdbc8.jar -DgroupId=com.oracle -DartifactId=ojdbc8 -Dversion=19.3 -Dpackaging=jar
	mvn install:install-file -Dfile=ucp.jar -DgroupId=com.oracle -DartifactId=ucp -Dversion=19.3 -Dpackaging=jar

# Converted to Oracle
* pom.xml <groupId>com.oracle
* application.properties jdbc:oracle.thin and oracle.jdbc.OracleDriver


# Start Eclipse
* Open CMD window
* cd %HOMEPATH%
* eclipse.bat


# Start Service
### Note changed default port in applicaton.property (server.port=8083)
* In Eclipse set a Run Configuration:
Type: Spring Boot App
MainType: com.basic.ws.app.MobileAppWsApplication
* Click Run
* Verify Start up:
Started MobileAppWsApplication in XX.YYY seconds


# Run standalone with POM and Internal Tomcat (Port: 8083)
* set JAVA_HOME=C:\Users\brideaum\Software\Java\jdk-11.0.6
* set PATH=%JAVA_HOME%\bin;%PATH%
* cd C:\Projects\NLAC\eclipse\eclipse-workspace0\basic-ws-app
* mvn clean
* mvn install
* mvn spring-boot:run

### To run on Tomcat we need to specify a Context Path in application.properties
* server.servlet.context-path=/basic_ws_app
* Update all Postman to include /basic_ws_app

### Run as standard java app
* set PATH="C:\Users\brideaum\Software\Java\jdk-11.0.6\bin";%PATH%
* mvn clean install
* cd C:\Users\brideaum\Software\Eclipse\eclipse-workspace\basic_ws_app
* java -jar target\basic_ws_app.jar
** ...Tomcat started on port(s): 8085 (http) with context path '/basic_ws_app'

### Build Work File requires a couple updates
* Update MobileAppWsApplication
** extends SpringBootServletInitializer
** add SpringApplicationBuilder configure(SpringApplicationBuilder application)
** Update POM <packaging> from JAR to WAR
** Add dependency <

### Deploy to tomcat running on port 8089
* Startup Tomcat:

	C:\Users\brideaum\Software\Apache\apache-tomcat-9.0.17\bin>startup
	Using CATALINA_BASE:   "C:\Users\brideaum\Software\Apache\apache-tomcat-9.0.17"
	Using CATALINA_HOME:   "C:\Users\brideaum\Software\Apache\apache-tomcat-9.0.17"
	Using CATALINA_TMPDIR: "C:\Users\brideaum\Software\Apache\apache-tomcat-9.0.17\temp"
	Using JRE_HOME:        "C:\Users\brideaum\Software\Java\jdk-11.0.6"
	Using CLASSPATH:       "C:\Users\brideaum\Software\Apache\apache-tomcat-9.0.17\bin\bootstrap.jar;C:\Users\brideaum\Software\Apache\apache-tomcat-9.0.17\bin\tomcat-juli.jar"




.
.
.
.
.
.
.
.
# Extra Runtime notes:
com.mysql.cj.jdbc.exceptions.CommunicationsException: Communications link failure

The last packet sent successfully to the server was 0 milliseconds ago. The driver has not received any packets from the server.
	at com.mysql.cj.jdbc.exceptions.SQLError.createCommunicationsException(SQLError.java:174) ~[mysql-connector-java-8.0.19.jar:8.0.19]

>>>>>>>>>>>> MYSQL not running. Execute mysqld


# To Test the WebService in Postman:

## 1. Create user to obtain encrypted UserId
curl --location --request POST 'http://localhost:8083/basic-ws-app/users' \
--header 'Content-Type: application/json' \
--header 'Accept: application/json' \
--data-raw '{
   "firstName":"Ben",
   "lastName":"Bulbbous",
   "email":"bBulbbous@gmail.com",
   "password":"marc4snow",
   "addresses":[{
   		"streetName":"88 Schott Dr.",
   		"city":"Pine",
   		"country":"USA",
   		"postalCode":"80470",
   		"type":"shipping"
   },
   {
		"streetName":"250 CR 250th",
    	"city":"Janesville",
   		"country":"USA",
   		"postalCode":"51282",
   		"type":"billing"
   },
   {
		"streetName":"890 2nd St. NW",
    	"city":"Janesville",
   		"country":"USA",
   		"postalCode":"51285",
   		"type":"billing"
   }
   ]
}'
### 1a. Response:
	{
	    "userId": "v5UNde2TQ7I4CwPZK79JUu0gLH8PCQ",
	    "firstName": "Ben",
	    "lastName": "Bulbbous",
	    "email": "bBulbbous@gmail.com",
	    "addresses": [
	        {
	            "addressId": "xI1id2u1wHEBLm1eAyorvz0TQUnEEV",
	            "streetName": "88 Schott Dr.",
	            "city": "Pine",
	            "country": "USA",
	            "postalCode": "80470",
	            "type": "shipping"
	        },
	        {
	            "addressId": "M17VgZ0qBT9MmOIX0c0zThj6Dr2cV8",
	            "streetName": "250 CR 250th",
	            "city": "Janesville",
	            "country": "USA",
	            "postalCode": "51282",
	            "type": "billing"
	        },
	        {
	            "addressId": "oLaYxsdckj99tWkciNiDhHyR1hzXsL",
	            "streetName": "890 2nd St. NW",
	            "city": "Janesville",
	            "country": "USA",
	            "postalCode": "51285",
	            "type": "billing"
	        }
	    ]
	}
## 2. Login with email and Password to obtain Encrypted UserId and Authorization
	curl --location --request POST 'http://localhost:8083/basic-ws-app/users/login' \
	--header 'Content-Type: application/json' \
	--data-raw '{
	   "email":"bBulbbous@gmail.com",
	   "password":"marc4snow"
	}'
### a. Response 'Headers':
	Authorization: 
	Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJiQnVsYmJvdXNAZ21haWwuY29tIiwiZXhwIjoxNjIyODQzMTk0fQ.KhuwSh2p9MLzXvB7DmXF5ExGti8RTY4v8h3gpYOilvk9AJs7dU98v4n-3POPo-L-VunSOm43lCe35Npu6H1iCQ
	
	UserID: 
	v5UNde2TQ7I4CwPZK79JUu0gLH8PCQ
	

## 3 Get Users with Authorization Token:
	curl --location --request GET 'http://localhost:8083/basic-ws-app/users/getUsers' \
	--header 'Authorization: Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJiQnVsYmJvdXNAZ21haWwuY29tIiwiZXhwIjoxNjIyODQzMTk0fQ.KhuwSh2p9MLzXvB7DmXF5ExGti8RTY4v8h3gpYOilvk9AJs7dU98v4n-3POPo-L-VunSOm43lCe35Npu6H1iCQ' \
	--header 'Accept: application/json'

* Get User by ID: http://localhost:8083/basic_ws_app/users/v5UNde2TQ7I4CwPZK79JUu0gLH8PCQ

### a. Response Pretty:
	[
    {
        "userId": "v5UNde2TQ7I4CwPZK79JUu0gLH8PCQ",
        "firstName": "Ben",
        "lastName": "Bulbbous",
        "email": "bBulbbous@gmail.com",
        "addresses": [
            {
                "id": 2,
                "addressId": "xI1id2u1wHEBLm1eAyorvz0TQUnEEV",
                "streetName": "88 Schott Dr.",
                "city": "Pine",
                "country": "USA",
                "postalCode": "80470",
                "type": "shipping",
                "userDetails": {
                    "id": 1,
                    "userId": "v5UNde2TQ7I4CwPZK79JUu0gLH8PCQ",
                    "firstName": "Ben",
                    "lastName": "Bulbbous",
                    "email": "bBulbbous@gmail.com",
                    "encryptedPassword": "$2a$10$e8LZD/lCTQwsfbsbVMLogO5PujtFqQkiISAjC0X5Js26FWPu80fCm",
                    "emailVerificationToken": null,
                    "emailVerificationStatus": false,
                    "addresses": [
                        {
                            "id": 2,
                            "addressId": "xI1id2u1wHEBLm1eAyorvz0TQUnEEV",
                            "streetName": "88 Schott Dr.",
                            "city": "Pine",
                            "country": "USA",
                            "postalCode": "80470",
                            "type": "shipping"
                        },
                        {
                            "id": 3,
                            "addressId": "M17VgZ0qBT9MmOIX0c0zThj6Dr2cV8",
                            "streetName": "250 CR 250th",
                            "city": "Janesville",
                            "country": "USA",
                            "postalCode": "51282",
                            "type": "billing"
                        },
                        {
                            "id": 4,
                            "addressId": "oLaYxsdckj99tWkciNiDhHyR1hzXsL",
                            "streetName": "890 2nd St. NW",
                            "city": "Janesville",
                            "country": "USA",
                            "postalCode": "51285",
                            "type": "billing"
                        }
                    ]
                }
            },
            {
                "id": 3,
                "addressId": "M17VgZ0qBT9MmOIX0c0zThj6Dr2cV8",
                "streetName": "250 CR 250th",
                "city": "Janesville",
                "country": "USA",
                "postalCode": "51282",
                "type": "billing",
                "userDetails": {
                    "id": 1,
                    "userId": "v5UNde2TQ7I4CwPZK79JUu0gLH8PCQ",
                    "firstName": "Ben",
                    "lastName": "Bulbbous",
                    "email": "bBulbbous@gmail.com",
                    "encryptedPassword": "$2a$10$e8LZD/lCTQwsfbsbVMLogO5PujtFqQkiISAjC0X5Js26FWPu80fCm",
                    "emailVerificationToken": null,
                    "emailVerificationStatus": false,
                    "addresses": [
                        {
                            "id": 2,
                            "addressId": "xI1id2u1wHEBLm1eAyorvz0TQUnEEV",
                            "streetName": "88 Schott Dr.",
                            "city": "Pine",
                            "country": "USA",
                            "postalCode": "80470",
                            "type": "shipping"
                        },
                        {
                            "id": 3,
                            "addressId": "M17VgZ0qBT9MmOIX0c0zThj6Dr2cV8",
                            "streetName": "250 CR 250th",
                            "city": "Janesville",
                            "country": "USA",
                            "postalCode": "51282",
                            "type": "billing"
                        },
                        {
                            "id": 4,
                            "addressId": "oLaYxsdckj99tWkciNiDhHyR1hzXsL",
                            "streetName": "890 2nd St. NW",
                            "city": "Janesville",
                            "country": "USA",
                            "postalCode": "51285",
                            "type": "billing"
                        }
                    ]
                }
            },
            {
                "id": 4,
                "addressId": "oLaYxsdckj99tWkciNiDhHyR1hzXsL",
                "streetName": "890 2nd St. NW",
                "city": "Janesville",
                "country": "USA",
                "postalCode": "51285",
                "type": "billing",
                "userDetails": {
                    "id": 1,
                    "userId": "v5UNde2TQ7I4CwPZK79JUu0gLH8PCQ",
                    "firstName": "Ben",
                    "lastName": "Bulbbous",
                    "email": "bBulbbous@gmail.com",
                    "encryptedPassword": "$2a$10$e8LZD/lCTQwsfbsbVMLogO5PujtFqQkiISAjC0X5Js26FWPu80fCm",
                    "emailVerificationToken": null,
                    "emailVerificationStatus": false,
                    "addresses": [
                        {
                            "id": 2,
                            "addressId": "xI1id2u1wHEBLm1eAyorvz0TQUnEEV",
                            "streetName": "88 Schott Dr.",
                            "city": "Pine",
                            "country": "USA",
                            "postalCode": "80470",
                            "type": "shipping"
                        },
                        {
                            "id": 3,
                            "addressId": "M17VgZ0qBT9MmOIX0c0zThj6Dr2cV8",
                            "streetName": "250 CR 250th",
                            "city": "Janesville",
                            "country": "USA",
                            "postalCode": "51282",
                            "type": "billing"
                        },
                        {
                            "id": 4,
                            "addressId": "oLaYxsdckj99tWkciNiDhHyR1hzXsL",
                            "streetName": "890 2nd St. NW",
                            "city": "Janesville",
                            "country": "USA",
                            "postalCode": "51285",
                            "type": "billing"
                        }
                    ]
                }
            }
        ]
    }
]
		
	


