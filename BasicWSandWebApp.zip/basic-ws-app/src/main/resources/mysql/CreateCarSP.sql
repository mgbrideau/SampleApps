CREATE OR REPLACE PROCEDURE FIND_CARS_AFTER_YEAR(
    p_year IN car.year%TYPE,
    o_id OUT car.id%TYPE,
    o_year OUT car.year%TYPE,
    o_model OUT car.model%TYPE)
    AS
    BEGIN 
        SELECT id, year, model INTO o_id, o_year, o_model FROM car WHERE year >= p_year ORDER BY year;
    END;