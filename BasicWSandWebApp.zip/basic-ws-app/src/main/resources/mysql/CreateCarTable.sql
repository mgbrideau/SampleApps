CREATE OR REPLACE TABLE car (
    id int(10) NOT NULL AUTO_INCREMENT, 
    model varchar(50) NOT NULL, 
    year int(4) NOT NULL, 
    PRIMARY KEY (id));
 
INSERT INTO car (model, year) VALUES ('BMW', 2000);
INSERT INTO car (model, year) VALUES ('BENZ', 2010);
INSERT INTO car (model, year) VALUES ('PORCHE', 2005);
INSERT INTO car (model, year) VALUES ('PORCHE', 2004);