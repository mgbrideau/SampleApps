-- Login
mysql -u root -p 
[marc4snow]

CREATE DATABASE basic_webapp;
show databases;
GRANT ALL PRIVILEGES ON basic_webapp.* TO 'mbrideau'@'localhost';


EXIT;

mysql -u mbrideau -p basic_webapp

-- Run CreateUsersTable.sql and CreateAddresses.sql
