package com.basic.ws.app.ui.controller;

public enum RequestOperationName {
	DELETE
}
