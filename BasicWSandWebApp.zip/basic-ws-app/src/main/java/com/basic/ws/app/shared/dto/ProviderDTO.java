package com.basic.ws.app.shared.dto;

import java.util.List;

public class ProviderDTO {
	private String providerID;
	private String baseTemplateId;
	private String descriptionTxt;
	private String doNotifyUserStatus;
	private String isAutoPurge;
	private String isLocalNlac;
	private String isTemplate;
	private String siteUrl;
	
	private List<ProviderDTO> providers;

	public String getProviderID() {
		return providerID;
	}

	public void setProviderID(String providerID) {
		this.providerID = providerID;
	}

	public String getBaseTemplateId() {
		return baseTemplateId;
	}

	public void setBaseTemplateId(String baseTemplateId) {
		this.baseTemplateId = baseTemplateId;
	}

	public String getDescriptionTxt() {
		return descriptionTxt;
	}

	public void setDescriptionTxt(String descriptionTxt) {
		this.descriptionTxt = descriptionTxt;
	}

	public String getDoNotifyUserStatus() {
		return doNotifyUserStatus;
	}

	public void setDoNotifyUserStatus(String doNotifyUserStatus) {
		this.doNotifyUserStatus = doNotifyUserStatus;
	}

	public String getIsAutoPurge() {
		return isAutoPurge;
	}

	public void setIsAutoPurge(String isAutoPurge) {
		this.isAutoPurge = isAutoPurge;
	}

	public String getIsLocalNlac() {
		return isLocalNlac;
	}

	public void setIsLocalNlac(String isLocalNlac) {
		this.isLocalNlac = isLocalNlac;
	}

	public String getIsTemplate() {
		return isTemplate;
	}

	public void setIsTemplate(String isTemplate) {
		this.isTemplate = isTemplate;
	}

	public String getSiteUrl() {
		return siteUrl;
	}

	public void setSiteUrl(String siteUrl) {
		this.siteUrl = siteUrl;
	}

	public List<ProviderDTO> getProviders() {
		return providers;
	}

	public void setProviders(List<ProviderDTO> providers) {
		this.providers = providers;
	}
	
}
