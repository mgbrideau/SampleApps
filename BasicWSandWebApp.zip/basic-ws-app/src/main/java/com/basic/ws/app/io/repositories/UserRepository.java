package com.basic.ws.app.io.repositories;

import org.springframework.data.repository.PagingAndSortingRepository;
//import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.basic.ws.app.io.entity.UserEntity;

// Repository provides a generic DAO for all the persistence methods
// Used by ServiceImpl classes
@Repository
//public interface UserRepository extends CrudRepository<T, ID> {
//public interface UserRepository extends CrudRepository<UserEntity, Long> {
// this new Repo has all the CRUD plus some
public interface UserRepository extends PagingAndSortingRepository<UserEntity, Long> {
	// create, delete, and updateUserEntry provided
	//UserEntity findUserByEmail(String email);
	
	// Enhanced Query must start with 'find', 'By', and an Entity field:
	UserEntity findByEmail(String email);
	
	// Enhanced Query must start with 'find', 'By', and an DB field:
	UserEntity findByUserId(String userId);

	// Enhanced Query must start with 'delete', 'By', and an DB field:
//	long deleteByUserId(String userId);
	
	
}
