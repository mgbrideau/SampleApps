package com.basic.ws.app.ui.model.response;

public enum RequestOperationStatus {
	ERROR, SUCCESS
}
