package com.basic.ws.app.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.basic.ws.app.io.entity.AddressEntity;
import com.basic.ws.app.io.entity.UserEntity;
import com.basic.ws.app.io.repositories.AddressRepository;
import com.basic.ws.app.io.repositories.UserRepository;
import com.basic.ws.app.service.AddressService;
import com.basic.ws.app.shared.dto.AddressDTO;

// This is @Service is required by Controller to autowire
@Service
public class AddressServiceImpl implements AddressService {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	AddressRepository addressRepository;
	
	@Override
	public List<AddressDTO> getAddresses(String userId) {
        List<AddressDTO> returnValue = new ArrayList<>();
        ModelMapper modelMapper = new ModelMapper();
        
        UserEntity userEntity = userRepository.findByUserId(userId);
        if(userEntity==null) return returnValue;
 
        Iterable<AddressEntity> addresses = addressRepository.findAllByUserDetails(userEntity);
        for(AddressEntity addressEntity:addresses)
        {
            returnValue.add( modelMapper.map(addressEntity, AddressDTO.class) );
        }
        
        
        return returnValue;
	}

	@Override
	public AddressDTO getAddress(String addressId) {
		AddressDTO addressDTO = null;
		
		AddressEntity addressEntity = addressRepository.findByAddressId(addressId);
		
		if(addressEntity != null) {
			addressDTO = new ModelMapper().map(addressEntity, AddressDTO.class);
		}
			
		return addressDTO;
	}
}
