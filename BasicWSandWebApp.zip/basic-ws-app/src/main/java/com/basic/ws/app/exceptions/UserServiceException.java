package com.basic.ws.app.exceptions;

public class UserServiceException extends RuntimeException {

	private static final long serialVersionUID = -7767099655439029535L;

	public UserServiceException(String message) {
		super(message);
	}

}
