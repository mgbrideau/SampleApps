package com.basic.ws.app.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.basic.ws.app.io.entity.UserEntity;
import com.basic.ws.app.shared.dto.UserDto;

// Added extends for compatibility with WebSecurity
public interface UserService extends UserDetailsService{
	UserDto createUser(UserDto user);
	UserDto updateUser(String userId, UserDto user);
	UserDto getUser(String email);
	UserDto getUserByUserId(String userId);
	void deleteUserByUserId(String userId);
	List<UserDto> getUsers(int page, int limit);

	List<UserEntity> getAllUsers();

}
