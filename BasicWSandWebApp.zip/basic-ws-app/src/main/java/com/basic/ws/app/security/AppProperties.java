package com.basic.ws.app.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

// This file needs to be a 'Conforment' for Bean DI with annotation
@Component
public class AppProperties {
	
	// DI with Autowired Environment
	@Autowired
	private Environment env;
	
	public String getTokenSecret()
	{
		return env.getProperty("tokenSecret");
	}

}
