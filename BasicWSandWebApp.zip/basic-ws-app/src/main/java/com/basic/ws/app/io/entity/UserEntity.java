package com.basic.ws.app.io.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// This class is persistent so we add Entity
// The name is the Table Name to persist to
@Entity(name="users")
public class UserEntity implements Serializable {

	private static final long serialVersionUID = 1820817776707646375L;
	
	// Primary Key that is auto incremented
	@Id
	@GeneratedValue
	private long id;

	// Required fields are not nullable
	@Column(nullable=false)
	private String userId;

	// Varchars are 256 chars by default
	@Column(nullable=false, length=50)
	private String firstName;
	
	@Column(nullable=false, length=50)
	private String lastName;
	
	// Make email unique by adding unique=true
//	@Column(nullable=false, length=120, unique=true)
	// Alternatively we can pre-query for email in Controller
	@Column(nullable=false, length=120)
	private String email;
	
	@Column(nullable=false)
	private String encryptedPassword;
	
	private String emailVerificationToken;
	
	// boolean default false is not portable across DBMS'
	// Also set this default in the DTO
//	@Column(nullable=false, columnDefinition = "boolean default false")
	@Column(nullable=false)
	private Boolean emailVerificationStatus = false;
	
	// Chp 99 OneToMany MappedBy is the 'owning' relationship.
	// Error with Recursion solved by JsonIgnoreProperites
	// https://hellokoding.com/handling-circular-reference-of-jpa-hibernate-bidirectional-entity-relationships-with-jackson-jsonignoreproperties/
	@OneToMany(mappedBy="userDetails", cascade=CascadeType.ALL)
	@JsonIgnoreProperties("userDetails")
	private List<AddressEntity> addresses;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEncryptedPassword() {
		return encryptedPassword;
	}

	public void setEncryptedPassword(String encryptedPassword) {
		this.encryptedPassword = encryptedPassword;
	}

	public String getEmailVerificationToken() {
		return emailVerificationToken;
	}

	public void setEmailVerificationToken(String emailVerificationToken) {
		this.emailVerificationToken = emailVerificationToken;
	}

	public Boolean getEmailVerificationStatus() {
		return emailVerificationStatus;
	}

	public void setEmailVerificationStatus(Boolean emailVerificationStatus) {
		this.emailVerificationStatus = emailVerificationStatus;
	}

	public List<AddressEntity> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<AddressEntity> addresses) {
		this.addresses = addresses;
	}
	

}
