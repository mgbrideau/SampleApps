package com.basic.ws.app.ui.controller;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.basic.ws.app.service.AddressService;
import com.basic.ws.app.service.UserService;
import com.basic.ws.app.shared.dto.AddressDTO;
import com.basic.ws.app.shared.dto.UserDto;
import com.basic.ws.app.ui.model.request.UserDetailsRequestModel;
import com.basic.ws.app.ui.model.response.AddressesRest;
import com.basic.ws.app.ui.model.response.OperationStatusModel;
import com.basic.ws.app.ui.model.response.RequestOperationStatus;
import com.basic.ws.app.ui.model.response.UserRest;

@RestController
@RequestMapping("/users") // http://localhost:8083/users
public class UserController {
	Logger log = LoggerFactory.getLogger(UserController.class);

	// Note for this Autowired to work the Impl class needs @Service Annotation!!
	@Autowired
	UserService userService;

	@Autowired
	AddressService addressService;

	// Chp 52 Add path parameter to this Endpoint mapping
	// This is the userId generated in the DB
	// Next we need to add the PathVariable annotation to the method parameter
	// Chp 57 Enable XML/JSON return/produces
	@GetMapping(path = "/{userId}", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public UserRest getUser(@PathVariable String userId) {
		log.info("UserController.Get User with ID: {}", userId);
		UserRest returnValue = new UserRest();

		// this is a new userService function we just created
		// 1. Controller calls UserService
		// 2. Service calls Repository that leverages JPA findBy<entity|table field>
		UserDto userDto = userService.getUserByUserId(userId);
		BeanUtils.copyProperties(userDto, returnValue);
		return returnValue;
	}

	@GetMapping(path = "/{userId}/addresses/{addressId}", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public AddressesRest getUserAddress(@PathVariable String addressId) {
		log.info("UserController.Get User with Address ID: {}, addressId");

		AddressDTO addressesDto = addressService.getAddress(addressId);
		
		ModelMapper modelMapper = new ModelMapper();
		
		AddressesRest addressesRest = modelMapper.map(addressesDto, AddressesRest.class);
		
		return addressesRest;
	}

//	@GetMapping
//	public String getAllUesrs() {returnValue
//		List<UserEntity> userList = userService.getAllUsers();
//		Gson gson = new Gson();
//		String json = gson.toJson(userList);
//		System.out.println(json);
//		return json;
//	}

	// Chp 57 add consumes/produces xml or json
//	public String creatUesr() {
//	public String creatUesr(@RequestBody UserDetailsRequestModel userDetails) {
	@PostMapping( consumes = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public UserRest createUser(@RequestBody UserDetailsRequestModel userDetails) throws Exception {
		log.info("UserController.Create User with UserDetails: {}", userDetails);
		// Notice the HTTPRequest body must contain a JSON mapped to
		// UserDetailsRequestModel
		// The JSON will be implicitly converted to a Java model object

		// return "create user was called";
		// return null;
		UserRest returnValue = new UserRest();
		if (userDetails.getFirstName().isEmpty())
			throw new NullPointerException("The Object was null");
//		if(userDetails.getFirstName().isEmpty()) throw new UserServiceException(ErrorMessages.MISSING_REQUIRED_FIELD.getErrorMessage());

//		 Chp 96 replace shallow copyProperties with ModelMapper
//		UserDto userDto = new UserDto();
//		BeanUtils.copyProperties(userDetails, userDto);
		ModelMapper modelMapper = new ModelMapper();
		UserDto userDto = modelMapper.map(userDetails, UserDto.class);

		UserDto createdUser = userService.createUser(userDto);
		returnValue = modelMapper.map(createdUser, UserRest.class);
		return returnValue;
	}

	// Setup Mapping for path an XML or JSON consumes/produces types
	// Add path variables for UserId and UserDetails parameter as the Request body
	// Set return type as UserRest and use the same logic as cerateUser
	@PutMapping(path = "/{id}", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_XML_VALUE,
					MediaType.APPLICATION_JSON_VALUE })
	public UserRest updateUser(@PathVariable String id, @RequestBody UserDetailsRequestModel userDetails) {
		log.info("UserController.Update User with ID: {}, id");
		UserRest returnValue = new UserRest();
		if (userDetails.getFirstName().isEmpty())
			throw new NullPointerException("The Object was null");

		UserDto userDto = new UserDto();

		BeanUtils.copyProperties(userDetails, userDto);
		// Change Service method from create to updateUser which needs to be implemented
		// Update user with given ID and user object
		UserDto updateUser = userService.updateUser(id, userDto);

		BeanUtils.copyProperties(updateUser, returnValue);
		return returnValue;
	}

	@DeleteMapping(path = "/{id}", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public OperationStatusModel deleteUser(@PathVariable String id) {
		log.info("UserController.Delete User with ID: {}, id");

		OperationStatusModel returnValue = new OperationStatusModel();
//		returnValue.setOperationName(RequestOperationName.DELETE.name());

		userService.deleteUserByUserId(id);
		returnValue.setOperationResult(RequestOperationStatus.SUCCESS.name());
		return returnValue;
	}

	@GetMapping(path = "/getUsers", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public List<UserRest> getUsers(@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "10") int limit) {
		log.info("UserController.Get Users: ");

		// Change from 0 based to 1 based paging
		if (page > 0)
			page = page - 1;

		List<UserRest> returnValue = new ArrayList<>();

		List<UserDto> users = userService.getUsers(page, limit);

		for (UserDto userDto : users) {
			UserRest userModel = new UserRest();
			BeanUtils.copyProperties(userDto, userModel);
			log.debug("\nUserModel: " + userModel.toString());
			returnValue.add(userModel);
		}
		log.info("\nreturnValue:  " + returnValue);
		return returnValue;
	}

	// See Generics for http://ModelMapper.com using Java.lang.reflect
	// http://localhost:8083/mobile-app-ws/users/jfhdjeufhdhdj/addressses
	@GetMapping(path = "/{id}/addresses", produces = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE })
	public List<AddressesRest> getUserAddresses(@PathVariable String id) {
		log.info("UserController.Get User Addresses with ID: {}, id");
		List<AddressesRest> returnValue = new ArrayList<>();

		List<AddressDTO> addressesDTO = addressService.getAddresses(id);

		if (addressesDTO != null && !addressesDTO.isEmpty()) {

			java.lang.reflect.Type listType = new TypeToken<List<AddressesRest>>() {
			}.getType();
			returnValue = new ModelMapper().map(addressesDTO, listType);
		}

		return returnValue;
	}
}
