package com.basic.ws.app;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.modelmapper.TypeToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.basic.ws.app.exceptions.UserServiceException;
import com.basic.ws.app.io.entity.AddressEntity;
import com.basic.ws.app.io.entity.UserEntity;
import com.basic.ws.app.io.repositories.UserRepository;
import com.basic.ws.app.service.impl.UserServiceImpl;
import com.basic.ws.app.shared.AmazonSES;
import com.basic.ws.app.shared.Utils;
import com.basic.ws.app.shared.dto.AddressDTO;
import com.basic.ws.app.shared.dto.UserDto;

class UserServiceImplTest {

	// Mocks for GetUser (copied @autowired's)
	@InjectMocks
	UserServiceImpl userService;

	@Mock
	UserRepository userRepository;

	// Additional Mocks for CreateUser:
	// Note: Utils had to be an @Component for this Autowired to work
	@Mock
	Utils utils;

	@Mock
	AmazonSES amazonSES;

	// Note: In the main WebApplication we add this with @Bean annotation
	@Mock
	BCryptPasswordEncoder bCryptPasswordEncoder;

	String userId = "98sjadf";
	String encryptedPassword = "sdfpoiejlk@#^&$)_#$";
	UserEntity userEntity;

	@BeforeEach
	void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
		userEntity = new UserEntity();
		userEntity.setId(1L);
		userEntity.setFirstName("Marc");
		userEntity.setLastName("Brideau");
		userEntity.setUserId(userId);
		userEntity.setEncryptedPassword(encryptedPassword);
		userEntity.setEmail("test@test.com");
		userEntity.setEmailVerificationToken("7htnfhr758");
		userEntity.setAddresses(getAddressesEntity());
	}

	@Test
	void testGetUser() {
		// userEntity is declared at class level and initialized in setup()

		// Mockito sets userRepository with userEntity for userService
		when(userRepository.findByEmail(anyString())).thenReturn(userEntity);

		UserDto userDto = userService.getUser("test@test.com");

		assertNotNull(userDto);
		assertEquals("Marc", userDto.getFirstName());

	}

//	@Test(excepted = UsernameNotFoundException.class) // JUnit 4
	@Test
	final void testGetUser_UsernameNotFoundException() {
		// Mockito sets userRepository with userEntity for userService
		// No matter what is passed in when userRepository.findByEmail is call return
		// null
		when(userRepository.findByEmail(anyString())).thenReturn(null);

		// Junit 5 with Lamda method
		assertThrows(UsernameNotFoundException.class,

				() -> {
					userService.getUser("test@test.com");
				}

		);

	}

	@Test
	final void testCreateuser() {

		// Mock all objects that are external by Autowired in UserServiceImpl.createUser
		// and need to be stubbed

		// Mock a null User:
		when(userRepository.findByEmail(anyString())).thenReturn(null);
		// Mock AddressId:
		when(utils.generateAddressId(anyInt())).thenReturn(";LSADJKFEWROI9845980987");
		// Mock UserId
		when(utils.generateUserId(anyInt())).thenReturn(userId);
		// Mock Encrypted PW
		when(bCryptPasswordEncoder.encode(anyString())).thenReturn(encryptedPassword);
		// Special Mock with any(Object)
		// userEntity is declared at class level and initialized in setup()
		when(userRepository.save(any(UserEntity.class))).thenReturn(userEntity);
		// DoNothing for AmazonSES Email Verification:
		// UserServiceImpl.createUser doesn't call amazon.verifyEmail (Debug with
		// breakpoints)
		Mockito.doNothing().when(amazonSES).verifyEmail(any(UserDto.class));

		// UserDto requires a list of addresses so mock them first
		AddressDTO addressDto = new AddressDTO();
		addressDto.setType("shipping");

		List<AddressDTO> addresses = new ArrayList<>();
		addresses.add(addressDto);

		UserDto userDto = new UserDto();
		userDto.setAddresses(addresses);

		userDto.setAddresses(getAddressesDto());
		userDto.setFirstName("Sergey");
		userDto.setLastName("Kargopolov");
		userDto.setPassword("12345678");
		userDto.setEmail("test@test.com");

		UserDto storedUserDetails = userService.createUser(userDto);
		assertNotNull(storedUserDetails);
		assertEquals(userEntity.getFirstName(), storedUserDetails.getFirstName());
		assertEquals(userEntity.getLastName(), storedUserDetails.getLastName());
		assertNotNull(storedUserDetails.getUserId());
		assertEquals(storedUserDetails.getAddresses().size(), userEntity.getAddresses().size());
		verify(utils, times(storedUserDetails.getAddresses().size())).generateAddressId(30);
		verify(bCryptPasswordEncoder, times(1)).encode("12345678");
		verify(userRepository, times(1)).save(any(UserEntity.class));

	}

	@Test
	final void testCreateUser_CreateUserServiceException() {
		when(userRepository.findByEmail(anyString())).thenReturn(userEntity);
		UserDto userDto = new UserDto();
		userDto.setAddresses(getAddressesDto());
		userDto.setFirstName("Sergey");
		userDto.setLastName("Kargopolov");
		userDto.setPassword("12345678");
		userDto.setEmail("test@test.com");

		assertThrows(UserServiceException.class,

				() -> {
					userService.createUser(userDto);
				}

		);
	}

	private List<AddressDTO> getAddressesDto() {
		AddressDTO addressDto = new AddressDTO();
		addressDto.setType("shipping");
		addressDto.setCity("Vancouver");
		addressDto.setCountry("Canada");
		addressDto.setPostalCode("ABC123");
		addressDto.setStreetName("123 Street name");

		AddressDTO billingAddressDto = new AddressDTO();
		billingAddressDto.setType("billling");
		billingAddressDto.setCity("Vancouver");
		billingAddressDto.setCountry("Canada");
		billingAddressDto.setPostalCode("ABC123");
		billingAddressDto.setStreetName("123 Street name");

		List<AddressDTO> addresses = new ArrayList<>();
		addresses.add(addressDto);
		addresses.add(billingAddressDto);

		return addresses;

	}

	private List<AddressEntity> getAddressesEntity() {
		List<AddressDTO> addresses = getAddressesDto();

		Type listType = new TypeToken<List<AddressEntity>>() {
		}.getType();

		return new ModelMapper().map(addresses, listType);
	}

}
