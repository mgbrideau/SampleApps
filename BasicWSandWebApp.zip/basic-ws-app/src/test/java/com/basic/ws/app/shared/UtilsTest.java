package com.basic.ws.app.shared;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

// Loads up SpringContext
//@RunWith(SpringRunner.class) //Legacy annotations
@ExtendWith(SpringExtension.class)
@SpringBootTest
class UtilsTest {

	@Autowired
	Utils utils;
	
	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testGenerateUserId() {
		String userId = utils.generateUserId(30);
		String userId2 = utils.generateUserId(30);
		
		assertNotNull(userId);
		assertTrue(userId.length() == 30);
		assertTrue( !userId.equalsIgnoreCase(userId2) );
		

	}

	@Test
	void testHasTokenExpired() {
//		String token ="eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJtZ2JyaWRlYXVAZ21haWwuY29tIiwiZXhwIjoxNTkxNTQzNjE2fQ.-ZHLCJHmYYeY7uuLbxrDxlQd3UH4c3kAB1KidphWRsFnrfsH_e0TUCPbrBnKOwRZnrkHCy8Lpr06VK8SauVkMw";
		String token = utils.generateEmailVerificationToken("notmadderwhat");
		assertNotNull(token);
		
		boolean hasTokenExpired = Utils.hasTokenExpired(token);
		
		assertFalse(hasTokenExpired);
	}

}
