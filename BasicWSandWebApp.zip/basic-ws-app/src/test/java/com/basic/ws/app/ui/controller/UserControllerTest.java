package com.basic.ws.app.ui.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.basic.ws.app.service.impl.UserServiceImpl;
import com.basic.ws.app.shared.dto.AddressDTO;
import com.basic.ws.app.shared.dto.UserDto;
import com.basic.ws.app.ui.model.response.UserRest;

class UserControllerTest {

	// UserController.getUser() uses UserService
	// UserService is Autowired and will need to have its objects MOCKED

	// InjectMocks instantiates a UserController and then includes the Mock for
	// userService
	@InjectMocks
	UserController userController;

	@Mock
	UserServiceImpl userService;
	
	UserDto userDto;
	
	final String USER_ID = "notarealvalue09874jduier";
	final String encryptedPassword = "sdfpoiejlk@#^&$)_#$";


	@BeforeEach
	void setUp() throws Exception {
		// UserController gets dynamically Autowired and mocks get Injected
		MockitoAnnotations.initMocks(this);
		
		userDto = new UserDto();
		userDto.setFirstName("Sergey");
		userDto.setLastName("Kargopolov");
		userDto.setEmail("test@test.com");
		userDto.setEmailVerificationStatus(Boolean.FALSE);
		userDto.setEmailVerificationToken(null);
		userDto.setUserId(USER_ID);
		userDto.setAddresses(getAddressesDto());
		userDto.setEncryptedPassword(encryptedPassword);

		


	}

	@Test
	void testGetUser() {
		// Behavior Driven Devleopment (BDD) \
		// Given -> When -> Then
		when(userService.getUserByUserId(anyString())).thenReturn(userDto);
		
		UserRest userRest = userController.getUser(USER_ID);
		
		assertNotNull(userRest);
		
		assertEquals(USER_ID, userRest.getUserId());
		assertEquals(userDto.getFirstName(), userRest.getFirstName());
		assertEquals(userDto.getLastName(), userRest.getLastName());
		
		assertTrue(userDto.getAddresses().size() == userRest.getAddresses().size());
		
	}
	
	private List<AddressDTO> getAddressesDto() {
		AddressDTO addressDto = new AddressDTO();
		addressDto.setType("shipping");
		addressDto.setCity("Vancouver");
		addressDto.setCountry("Canada");
		addressDto.setPostalCode("ABC123");
		addressDto.setStreetName("123 Street name");

		AddressDTO billingAddressDto = new AddressDTO();
		billingAddressDto.setType("billling");
		billingAddressDto.setCity("Vancouver");
		billingAddressDto.setCountry("Canada");
		billingAddressDto.setPostalCode("ABC123");
		billingAddressDto.setStreetName("123 Street name");

		List<AddressDTO> addresses = new ArrayList<>();
		addresses.add(addressDto);
		addresses.add(billingAddressDto);

		return addresses;

	}


}
