Spring 4 MVC Ajax Example
===============================
Template for Spring 4 MVC + jQuery Ajax + Jackson2, using Maven build tool.


# Udemy:
https://www.udemy.com/course/restful-web-service-with-spring-boot-jpa-and-mysql/learn/lecture/9798084#overview


# Quick App Start
### Start MySQL
* Open CMD window: mysqld
* Open MySQL Workbench
* Query meetings.Users

### Start nlac-admin-app
* com.nlac.app.ws.MobileAppWsApplicaiton -> Run As Java Application
* Wait for: Started MobileAppWsApplication in 10.248 seconds (JVM running for 11.599)

### Run Postman
* Run Post NLAC user - Create 
* Run Post NLAC user - Login 
- Capture Bearer
* Run Get NLAC users

### Run Web Application:
* spring-mvc-ajax-rest -> Maven Clean/Install -> Run As: On Server



## My Notes:
###1. Converted to make webservice call to nlac-admin-app
* Start nlac-admin-app Spring Boot app on Port 8083 first
* sqlplus> grant create PROCEDURE to mbrideau;

###1. Technologies used
* Spring 4.2.2.RELEASE
* Jackson 2.6.3
* jQuery 1.10.2
* Boostrap 3
* Maven 3

###2. To Run this project locally
```shell
$ git clone https://github.com/mkyong/spring4-mvc-ajax-example
$ cd spring4-mvc-ajax-example
$ mvn jetty:run
```
Access ```http://localhost:8080/spring4ajax```

###3. To import this project into Eclipse IDE
1. ```$ mvn eclipse:eclipse```
2. Import into Eclipse via **existing projects into workspace** option.
3. Done.

###4. Project Demo
Please refer to this article [Spring 4 Ajax Example](http://www.mkyong.com/spring-mvc/spring-4-mvc-ajax-hello-world-example/)
