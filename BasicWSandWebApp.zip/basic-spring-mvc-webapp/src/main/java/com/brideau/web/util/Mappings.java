package com.brideau.web.util;

public final class Mappings {


	// == pages ==
	public static final String WEB_CONTEXT= "/basic-spring-mvc-webapp";
	public static final String HOME_PAGE = "/";
	public static final String USER_HOME = "/user/api/home";
	public static final String USER_LOGIN = "/user/api/userLogin";
	public static final String GET_USER_LIST = "/user/api/getUsers";
	

	// == constructors ==
	private Mappings() {
	}
}
