package com.brideau.web.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.brideau.web.jsonview.Views;
import com.brideau.web.model.User;
import com.brideau.web.model.UserRest;
import com.brideau.web.util.Mappings;
import com.brideau.web.util.ViewNames;
import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
@Scope("session")
public class AjaxController {

	Logger log = LoggerFactory.getLogger(AjaxController.class);
	List<User> users;

	// Session scoped attribute(s):
	@Autowired
	User user;

	// Please note the 'home page' is defined in
	@JsonView(Views.Public.class)
	@RequestMapping(value = "/user/api/userLogin", method = RequestMethod.POST)
	public ModelAndView userLogin(@ModelAttribute("user") User user, BindingResult result, ModelAndView mv,
			HttpServletRequest request) {
		if (isValidUser(user)) {
			user = findByUserNameOrEmail(user.getEmail(), user.getPassword());
			if (!StringUtils.isEmpty(user.getAuthorization()) || !StringUtils.isEmpty(user.getUserId())) {
				mv.addObject("user", user);
				log.info("Successful Logon UserId: {}", user.getUserId());
//				request.getSession().setAttribute("user", user);
				mv.setViewName(ViewNames.HOME);
			} else {
				user.setCode("204");
				user.setMsg("No user!");
				mv.addObject("errorMessage", user);
				log.info("Unsuccessful No User: ", user.toString());
				mv.setViewName(ViewNames.ERROR);
			}

		} else {
			user.setCode("400");
			user.setMsg("Logon username or password was empty!");
			mv.addObject("errorMessage", user);
			log.info("Logon username or password was empty!: ", user.toString());
			mv.setViewName("error");
		}

		// AjaxResponseBody will be converted into json format and send back to client.
		this.user = user;
		return mv;

	}

	// == handler methods ==
	@GetMapping(value = "/user/api/home")
	public ModelAndView getHome(ModelAndView mv) {
		mv.setViewName(ViewNames.HOME);
		return mv;
	}

	@GetMapping(Mappings.GET_USER_LIST)
	public ModelAndView getUsers(ModelAndView mv) {
//		public ModelAndView getUsers(@ModelAttribute("user")User user, BindingResult result, ModelAndView mv, HttpServletRequest request) {
//		User sessionUser = (User)request.getSession().getAttribute("user");
//		log.info(">>>>>> Session User: {}", sessionUser.toString());
		log.info(">>>>>> Autowired Session User: {}", this.user.toString());
		mv.addObject("userList", user);
		log.info("Calling userService.getUserList()");
		ArrayList<UserRest> userList = this.getUserList();
		log.info("User List: " + userList);
		mv.addObject("userList", userList);
		mv.setViewName(ViewNames.USER_LIST);
		return mv;
	}

	@GetMapping(value = "/user/api/error")
	public String viewError() {
		return "error";
	}

	private boolean isValidUser(User user) {

		boolean valid = true;

		if (user == null) {
			valid = false;
		}

		if ((StringUtils.isEmpty(user.getEmail())) || (StringUtils.isEmpty(user.getPassword()))) {
			valid = false;
		}

		return valid;
	}

	private ArrayList<UserRest> getUserList() {
		ArrayList<UserRest> userList = new ArrayList<UserRest>();
		try {
			/*
			 * Perform GetUserList with Postman Code: curl --location --request GET
			 * 'http://localhost:8083/basic-ws-app/users/getUsers' \ --header
			 * 'Authorization: Bearer eyJhbGciOiJIUzUxMiJ9.
			 * eyJzdWIiOiJiYmJ1bGJidXNAZ21haWwuY29tIiwiZXhwIjoxNTg5Mjk0MTEzfQ.
			 * mS2uGHNl3cuEF3W9Pu5RaxJStkwu45448mjuMm5Ej29n9I9Akl_lpxZAAS6QDpTOWKgSwBrtB4zR4HFjPm_mGA'
			 */

			URL postURL = new URL("http://localhost:8083/basic-ws-app/users/getUsers");
			HttpURLConnection postConn = (HttpURLConnection) postURL.openConnection();
			postConn.setDoOutput(true);
			postConn.setRequestMethod("GET");
			String userAuth = user.getAuthorization();
			String header = "Authorization";
			postConn.setRequestProperty(header, userAuth);
			postConn.setRequestProperty("Accept", "application/json");

			if (postConn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : " + postConn.getResponseCode());
			} else {
				System.out.println("Successfully queried users");
			}

			log.info("Response Code {}", postConn.getResponseCode());
			log.info("Response message {}", postConn.getResponseMessage());
			BufferedReader br = null;
			if (postConn.getResponseCode() == 200) {
				br = new BufferedReader(new InputStreamReader(postConn.getInputStream()));
//			    https://stackoverflow.com/questions/17037340/converting-jsonarray-to-arraylist/17037364
				ObjectMapper mapper = new ObjectMapper();
				String strCurrentLine;
				while ((strCurrentLine = br.readLine()) != null) {
					System.out.println(strCurrentLine);
					ArrayList<String> listdata = new ArrayList<String>();
					userList = mapper.readValue(strCurrentLine, ArrayList.class);
					System.out.println("userList: " + userList);
//			               JsonArray jArray = new JsonArray(strCurrentLine); 
//			               if (jArray != null) { 
//			                  for (int i=0;i<jArray.length();i++){ 
//			                   listdata.add(jArray.getString(i));
//			                  } 
//			               } 			        
				}
			} else {
				br = new BufferedReader(new InputStreamReader(postConn.getErrorStream()));
				String strCurrentLine;
				while ((strCurrentLine = br.readLine()) != null) {
					System.out.println(strCurrentLine);
				}
			}
			postConn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		return userList;
	}

	private User userLogin(String email, String password) {
		User user = new User();
		user.setEmail(email);
		user.setPassword(password);
		try {
			/*
			 * Perform GetUser with Postman Code:
			 * 
			 * curl --location --request POST
			 * 'http://localhost:8083/basic-ws-app/users/login' \ --header 'Content-Type:
			 * application/json' \ --header 'Content-Type: text/plain' \ --data-raw '{
			 * "email":"mgbrideau1@gmail.com", "password":"marc4snow" }'
			 */

			URL postURL = new URL("http://localhost:8083/basic-ws-app/users/login");
			HttpURLConnection postConn = (HttpURLConnection) postURL.openConnection();
			postConn.setDoOutput(true);
			postConn.setRequestMethod("POST");
			postConn.setRequestProperty("Accept", "application/json");

			String input = "{\"email\":\"" + email + "\",\"password\":\"" + password + "\"}";

			OutputStream os = postConn.getOutputStream();
			os.write(input.getBytes());
			os.flush();

			if (postConn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				user.setMsg(
						"ResponseCode: " + postConn.getResponseCode() + " \nMessage: " + postConn.getResponseMessage());
				log.info("RestCall failed, Status: {}, Message: {}", postConn.getResponseCode(),
						postConn.getResponseMessage());
				return user;
//				throw new RuntimeException("Failed : HTTP error code : " + postConn.getResponseCode());
			} else {
				System.out.println("Successful Login");
			}

			String userID = postConn.getHeaderFields().get("UserID").get(0);
			String authorization = postConn.getHeaderFields().get("Authorization").get(0);
			System.out.println("\nUserId: " + userID);
			System.out.println("Authorization: " + authorization);

			user.setUserId(userID);
			user.setAuthorization(authorization);

			postConn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		return user;
	}

	private User findByUserNameOrEmail(String email, String password) {

		User result = new User();
		User loggedInUser = new User();

		if ((!StringUtils.isEmpty(email)) && (!StringUtils.isEmpty(password))) {
			loggedInUser = userLogin(email, password);
			System.out.println("Logged in User: " + loggedInUser);
			if (email.equals(loggedInUser.getEmail()) && password.equals(loggedInUser.getPassword())) {
				// TODO: Replace with BeanUtils.copyProperties(userDetails, userDto);
				result.setEmail(email);
				result.setPassword(password);
				result.setAuthorization(loggedInUser.getAuthorization());
				result.setUserId(loggedInUser.getUserId());
			} else {
				result = loggedInUser;
			}

		}
		System.out.println("UserLoginUser: " + result.toString());
		return result;

	}
}
