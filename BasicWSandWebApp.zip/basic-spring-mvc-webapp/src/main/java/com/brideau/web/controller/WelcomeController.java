package com.brideau.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.brideau.web.model.User;
import com.brideau.web.util.ViewNames;

@Controller
public class WelcomeController {

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView printWelcome(ModelAndView modelAndView) {
		modelAndView.addObject("user", new User());
		modelAndView.setViewName(ViewNames.LOGIN);
		return modelAndView;
	}

}
