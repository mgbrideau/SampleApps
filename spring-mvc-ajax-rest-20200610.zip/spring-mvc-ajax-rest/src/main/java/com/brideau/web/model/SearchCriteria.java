package com.brideau.web.model;

public class SearchCriteria {

	String userEmail;
	String password;
	String code;
	String msg;


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}


	@Override
	public String toString() {
		return "SearchCriteria [userEmail=" + userEmail + ", password=" + password
				+ "]";
	}

}
