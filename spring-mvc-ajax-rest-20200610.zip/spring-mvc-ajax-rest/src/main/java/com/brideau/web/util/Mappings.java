package com.brideau.web.util;

public final class Mappings {


	// == pages ==
	public static final String WEB_CONTEXT= "/spring-mvc-maven-ajax-rest";
	public static final String HOME_PAGE= "/";
	

	// == constructors ==
	private Mappings() {
	}
}
