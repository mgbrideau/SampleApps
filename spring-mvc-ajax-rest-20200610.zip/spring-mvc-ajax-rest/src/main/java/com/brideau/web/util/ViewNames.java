package com.brideau.web.util;

public final class ViewNames {

    // == View constants ==
    public static final String LOGIN = "login";
    public static final String HOME = "home";
    
    public static final String USER_LIST = "userList";
    public static final String USER_CREATE = "userCreate";
    public static final String USER_DETAILS = "userDetials";
    
    public static final String ERROR = "error";
    


    // == constructors ==
    private ViewNames() {}
}
