package com.brideau.web.util;

public final class AttributeNames {

	// == constants ==
	public static final String APP_TITLE = "NLAC Administration Web Application";

	public static final String HOME_PAGE_TITLE = "Welcome to NLAC Administration";
	public static final String LOGIN_PAGE = "Login Page";
	public static final String LOGIN_BUTTON_LABEL = "Submit";
	public static final String LOGIN_BUTTON_ACTION = "search-form";

	public static final String ERROR_PAGE = "Error Page";
	
	// == constructors ==
	private AttributeNames() {
	}
}
