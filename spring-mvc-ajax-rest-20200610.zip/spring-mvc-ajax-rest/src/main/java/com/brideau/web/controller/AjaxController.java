package com.brideau.web.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.brideau.web.jsonview.Views;
import com.brideau.web.model.User;
import com.fasterxml.jackson.annotation.JsonView;


@Controller
public class AjaxController {

	List<User> users;
	User user;

	@JsonView(Views.Public.class)
	// @RequestMapping(value = "/user/api/userLogin")
	@RequestMapping(value = "/user/api/userLogin", method = RequestMethod.POST)
	public ModelAndView userLogin(@ModelAttribute("user")User user, BindingResult result, ModelAndView mv) {
//		@Valid @ModelAttribute("employee")Employee employee, 
//	      BindingResult result, ModelMap model
//		ModelAndView mv = new ModelAndView();
		if (isValidUser(user)) {
			user = findByUserNameOrEmail(user.getEmail(), user.getPassword());
			if (!StringUtils.isEmpty(user.getAuthorization()) || !StringUtils.isEmpty(user.getUserId())) {
				mv.addObject("user", user);
				System.out.println("UserLogin User: " + user);
				mv.setViewName("welcome");
			} else {
				user.setCode("204");
				user.setMsg("No user!");
				mv.addObject("errorMessage", user);
				System.out.println("UserLogin User: " + user);
				mv.setViewName("welcome");
			}

		} else {
			user.setCode("400");
			user.setMsg("Logon username or password was empty!");
			mv.addObject("errorMessage", user);
			System.out.println("UserLogin User: " + user);
			mv.setViewName("error");
		}

		// AjaxResponseBody will be converted into json format and send back to client.
		return mv;

	}

	@GetMapping(value = "/user/api/error")
	public String viewVehicle() {
		return "error";
	}

	private boolean isValidUser(User user) {

		boolean valid = true;

		if (user == null) {
			valid = false;
		}

		if ((StringUtils.isEmpty(user.getEmail())) || (StringUtils.isEmpty(user.getPassword()))) {
			valid = false;
		}

		return valid;
	}

	private User userLogin(String email, String password) {
		User user = new User();
		user.setEmail(email);
		user.setPassword(password);
		try {
			/*
			 * Perform GetUser with Postman Code:
			 * 
			 * curl --location --request POST
			 * 'http://localhost:8083/mobile-app-ws/users/login' \ --header 'Content-Type:
			 * application/json' \ --header 'Content-Type: text/plain' \ --data-raw '{
			 * "email":"mgbrideau1@gmail.com", "password":"marc4snow" }'
			 */

			URL postURL = new URL("http://localhost:8083/nlac-admin-app/users/login");
			HttpURLConnection postConn = (HttpURLConnection) postURL.openConnection();
			postConn.setDoOutput(true);
			postConn.setRequestMethod("POST");
			postConn.setRequestProperty("Accept", "application/json");

			String input = "{\"email\":\"" + email + "\",\"password\":\"" + password + "\"}";

			OutputStream os = postConn.getOutputStream();
			os.write(input.getBytes());
			os.flush();

			if (postConn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				throw new RuntimeException("Failed : HTTP error code : " + postConn.getResponseCode());
			} else {
				System.out.println("Successful Login");
			}

			String userID = postConn.getHeaderFields().get("UserID").get(0);
			String authorization = postConn.getHeaderFields().get("Authorization").get(0);
			System.out.println("\nUserId: " + userID);
			System.out.println("Authorization: " + authorization);

			user.setUserId(userID);
			user.setAuthorization(authorization);

			postConn.disconnect();

		} catch (MalformedURLException e) {

			e.printStackTrace();

		} catch (IOException e) {

			e.printStackTrace();

		}
		return user;
	}

	private User findByUserNameOrEmail(String email, String password) {

		User result = new User();
		User loggedInUser = new User();

		if ((!StringUtils.isEmpty(email)) && (!StringUtils.isEmpty(password))) {
			loggedInUser = userLogin(email, password);
			System.out.println("Logged in User: " + loggedInUser);
			if (email.equals(loggedInUser.getEmail()) && password.equals(loggedInUser.getPassword())) {
				// TODO: Replace with BeanUtils.copyProperties(userDetails, userDto);
				result.setEmail(email);
				result.setPassword(password);
				result.setAuthorization(loggedInUser.getAuthorization());
				result.setUserId(loggedInUser.getUserId());
			}

		}
		System.out.println("UserLoginUser: " + result.toString());
		return result;

	}
}
