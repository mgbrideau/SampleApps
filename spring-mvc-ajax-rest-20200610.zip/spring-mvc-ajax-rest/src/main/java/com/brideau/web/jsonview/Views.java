package com.brideau.web.jsonview;

public class Views {
    public static class Public {}
}
