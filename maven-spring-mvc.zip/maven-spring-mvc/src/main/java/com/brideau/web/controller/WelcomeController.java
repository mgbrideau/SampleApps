package com.brideau.web.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.brideau.web.model.ServiceRecord;
import com.brideau.web.util.Mappings;
import com.brideau.web.util.ViewNames;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class WelcomeController {

	@InitBinder
	 public void initDateBinder(final WebDataBinder binder) {
	        binder.registerCustomEditor(Date.class, new CustomDateEditor(new SimpleDateFormat("MM/dd/yyyy"), true));
	 }
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView printWelcome(ModelAndView modelAndView) {
		log.info("ModelAndView printWelcome: ");
		modelAndView.setViewName(ViewNames.HOME);
		return modelAndView;
	}

	@RequestMapping(value = Mappings.ADD_SERVICE, method = RequestMethod.POST)
	public ModelAndView displayNewServiceRecordForm(ServiceRecord serviceRecord, BindingResult bindingResult, Model model) {
		log.info("Add Service with Model Date: {}", model.toString());
		ModelAndView mv = new ModelAndView(ViewNames.ADD_SERVICE);
		mv.addObject("message", "Add Service Record Details");
		mv.addObject("serviceRecord", serviceRecord);
		return mv;
	}

//	@RequestMapping(value = Mappings.ADD_SERVICE, method = RequestMethod.POST)
//	public ModelAndView saveNewServiceRecord(@ModelAttribute ServiceRecord serviceRecord, BindingResult result, Model model) {
//		log.info("Adding ServiceRecord: {}", serviceRecord.toString());
//		ModelAndView mv = new ModelAndView(ViewNames.SERVICE_RECORDS);
//		if (result.hasErrors()) {
//			return new ModelAndView(ViewNames.ERROR);
//		}
//		boolean isAdded = vehicleService.saveServiceRecord(serviceRecord);
//		if (isAdded) {
//			log.info("saveNewServiceRecored {}", serviceRecord.getService_details());
//			mv.addObject("message", "New serviceRecord successfully added");
//		} else {
//			return new ModelAndView(ViewNames.ERROR);
//		}
//		Vehicle vehicle = vehicleService.getVehicleById(serviceRecord.getVehicle_id());
//		model.addAttribute(AttributeNames.VEHICLE, vehicle);
//		List<ServiceRecord> serviceList = vehicleService.getServiceRecordsByVehicleId(serviceRecord.getVehicle_id());
//		mv.addObject("serviceList", serviceList);
//		return mv;
//	}
}
