package com.brideau.web.util;

public final class AttributeNames {

	// == constants ==
	public static final String APP_TITLE = "Administration Web Application";

	public static final String HOME_PAGE_TITLE = "Welcome to Web Administration";
	public static final String RESULTS_PAGE_TITLE = "Results of Home page submission";
	public static final String LOGIN_BUTTON_LABEL = "Submit";

	public static final String ERROR_PAGE = "Error Page";
    public static final String SERVICE_RECORD = "serviceRecord";

	// == constructors ==
	private AttributeNames() {
	}
}
