package com.brideau.web.util;

public final class ViewNames {

    // == View constants ==
    public static final String HOME = "home";
    public static final String ERROR = "error";
	public static final String ADD_SERVICE = "add_service";
    


    // == constructors ==
    private ViewNames() {}
}
