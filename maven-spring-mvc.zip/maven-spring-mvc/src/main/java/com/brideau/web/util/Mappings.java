package com.brideau.web.util;

public final class Mappings {


	// == pages ==
	public static final String WEB_CONTEXT= "/maven-spring-mvc";
	public static final String HOME_PAGE = "/";
	public static final String ADD_SERVICE = "addService";
	

	// == constructors ==
	private Mappings() {
	}
}
