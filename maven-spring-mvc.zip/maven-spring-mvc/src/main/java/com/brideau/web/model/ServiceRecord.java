package com.brideau.web.model;

import org.springframework.format.annotation.DateTimeFormat;
import java.util.Date;

public class ServiceRecord {
	

	@DateTimeFormat(pattern = "MM-dd-yyyy")
	private Date birthdate;	
	

}